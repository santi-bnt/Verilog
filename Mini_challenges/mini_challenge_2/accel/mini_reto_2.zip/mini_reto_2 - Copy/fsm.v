module fsm(
    input clk,
    input rst,
    input start,
    input selector,
    input guardar,
    output reg  LEDR
);

endmodule