module vga_demo(
    input MAX10_CLK1_50,
    input [7:0] motor1,
    input [7:0] motor2,
    input [7:0] motor3,
    input [7:0] motor4,
    output reg [2:0] pixel,
    output hsync_out,
    output vsync_out
);

wire inDisplayArea;
wire [9:0] CounterX;
wire [9:0] CounterY;

reg pixel_tick = 0;
always @(posedge MAX10_CLK1_50) begin
    pixel_tick <= ~pixel_tick;
end

vga hvsync_gen(
    .clk(MAX10_CLK1_50),
    .pixel_tick(pixel_tick), 
    .vga_h_sync(hsync_out),
    .vga_v_sync(vsync_out),
    .inDisplayArea(inDisplayArea),
    .CounterX(CounterX),
    .CounterY(CounterY)
);

// ==========================
// Separar centenas, decenas y unidades
// ==========================
wire [3:0] m1_c = motor1 / 100;
wire [3:0] m1_d = (motor1 / 10) % 10;
wire [3:0] m1_u = motor1 % 10;

wire [3:0] m2_c = motor2 / 100;
wire [3:0] m2_d = (motor2 / 10) % 10;
wire [3:0] m2_u = motor2 % 10;

wire [3:0] m3_c = motor3 / 100;
wire [3:0] m3_d = (motor3 / 10) % 10;
wire [3:0] m3_u = motor3 % 10;

wire [3:0] m4_c = motor4 / 100;
wire [3:0] m4_d = (motor4 / 10) % 10;
wire [3:0] m4_u = motor4 % 10;

// ==========================
// Función para segmentos
// bit [6:0] = {a,b,c,d,e,f,g}
// ==========================
function [6:0] segs;
    input [3:0] digit;
    begin
        case (digit)
            4'd0: segs = 7'b1111110;
            4'd1: segs = 7'b0110000;
            4'd2: segs = 7'b1101101;
            4'd3: segs = 7'b1111001;
            4'd4: segs = 7'b0110011;
            4'd5: segs = 7'b1011011;
            4'd6: segs = 7'b1011111;
            4'd7: segs = 7'b1110000;
            4'd8: segs = 7'b1111111;
            4'd9: segs = 7'b1111011;
            default: segs = 7'b0000000;
        endcase
    end
endfunction

// ==========================
// Parámetros del dígito
// ==========================
localparam DIG_W = 30;
localparam DIG_H = 50;
localparam THICK = 4;

// ==========================
// ¿pixel dentro de un dígito?
// ==========================
function digit_on;
    input [9:0] x;
    input [9:0] y;
    input [9:0] x0;
    input [9:0] y0;
    input [3:0] digit;

    reg [6:0] s;
    reg a_on, b_on, c_on, d_on, e_on, f_on, g_on;
    begin
        s = segs(digit);

        a_on = s[6] && (y >= y0) && (y < y0 + THICK) &&
               (x >= x0 + THICK) && (x < x0 + DIG_W - THICK);

        b_on = s[5] && (x >= x0 + DIG_W - THICK) && (x < x0 + DIG_W) &&
               (y >= y0 + THICK) && (y < y0 + DIG_H/2);

        c_on = s[4] && (x >= x0 + DIG_W - THICK) && (x < x0 + DIG_W) &&
               (y >= y0 + DIG_H/2) && (y < y0 + DIG_H - THICK);

        d_on = s[3] && (y >= y0 + DIG_H - THICK) && (y < y0 + DIG_H) &&
               (x >= x0 + THICK) && (x < x0 + DIG_W - THICK);

        e_on = s[2] && (x >= x0) && (x < x0 + THICK) &&
               (y >= y0 + DIG_H/2) && (y < y0 + DIG_H - THICK);

        f_on = s[1] && (x >= x0) && (x < x0 + THICK) &&
               (y >= y0 + THICK) && (y < y0 + DIG_H/2);

        g_on = s[0] && (y >= y0 + DIG_H/2 - THICK/2) && (y < y0 + DIG_H/2 + THICK/2) &&
               (x >= x0 + THICK) && (x < x0 + DIG_W - THICK);

        digit_on = a_on || b_on || c_on || d_on || e_on || f_on || g_on;
    end
endfunction

// ==========================
// Cada línea
// ==========================
wire line1_on, line2_on, line3_on, line4_on;

assign line1_on =
    digit_on(CounterX, CounterY,  80,  40, 4'd1) ||
    digit_on(CounterX, CounterY, 140,  40, m1_c) ||
    digit_on(CounterX, CounterY, 180,  40, m1_d) ||
    digit_on(CounterX, CounterY, 220,  40, m1_u);

assign line2_on =
    digit_on(CounterX, CounterY,  80, 110, 4'd2) ||
    digit_on(CounterX, CounterY, 140, 110, m2_c) ||
    digit_on(CounterX, CounterY, 180, 110, m2_d) ||
    digit_on(CounterX, CounterY, 220, 110, m2_u);

assign line3_on =
    digit_on(CounterX, CounterY,  80, 180, 4'd3) ||
    digit_on(CounterX, CounterY, 140, 180, m3_c) ||
    digit_on(CounterX, CounterY, 180, 180, m3_d) ||
    digit_on(CounterX, CounterY, 220, 180, m3_u);

assign line4_on =
    digit_on(CounterX, CounterY,  80, 250, 4'd4) ||
    digit_on(CounterX, CounterY, 140, 250, m4_c) ||
    digit_on(CounterX, CounterY, 180, 250, m4_d) ||
    digit_on(CounterX, CounterY, 220, 250, m4_u);

// ==========================
// Pintado
// ==========================
always @(posedge MAX10_CLK1_50) begin
    if (!inDisplayArea)
        pixel <= 3'b000;
    else if (line1_on || line2_on || line3_on || line4_on)
        pixel <= 3'b111;
    else
        pixel <= 3'b000;
end

endmodule