module counter_mem(
    input clk,
    input rst,
    input count_en,
    output reg [2:0] count
);

always @(posedge clk or posedge rst) begin
    if (rst)
        count <= 0;
    else if (count_en) begin
        if (count == 7)
            count <= 0;
        else
            count <= count + 1;
    end
end

endmodule