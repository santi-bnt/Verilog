module PWM (
    input clk,
    input rst,
    input [19:0] data_x_reg,
    input [19:0] data_y_reg,
    input [19:0] data_z_reg,

    output out_x,
    output out_y,
    output out_z
    
);
       
	wire clk_5mhz;
	

clk_divide #(
  .FREQ(5_000_000),
  .CLK_FREQ(25_000_000)
) u_div (
  .clk(clk),
  .rst(rst),
  .clk_div(clk_5mhz)
);

convertidor conv(
    .clk(clk_5mhz),
    .rst(rst),
    .data_x_reg(data_x_reg),
    .data_y_reg(data_y_reg),
    .data_z_reg(data_z_reg),
    .out_x(out_x),
    .out_y(out_y),
    .out_z(out_z)
);

 
    

endmodule