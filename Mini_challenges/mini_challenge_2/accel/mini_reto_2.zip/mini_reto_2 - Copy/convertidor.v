module convertidor(
    input wire clk,
    input wire rst,
    input wire signed [19:0] data_x_reg,
    input wire signed [19:0] data_y_reg,
    input wire signed [19:0] data_z_reg,

    output reg [7:0] angle_x,
    output reg [7:0] angle_y,
    output reg [7:0] angle_z
);

always @(posedge clk or posedge rst) begin
    if (rst) begin
        angle_x <= 0;
        angle_y <= 0;
        angle_z <= 0;
    end
    else begin
        angle_x <= 90 + (data_x_reg >>> 2);
        angle_y <= 90 + (data_y_reg >>> 2);
        angle_z <= 90 + (data_z_reg >>> 2);
    end
end

endmodule